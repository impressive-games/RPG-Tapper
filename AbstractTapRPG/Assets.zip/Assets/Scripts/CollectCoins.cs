﻿using UnityEngine;
using System.Collections;

public class CollectCoins : MonoBehaviour {
	private uint stndCooper = 5;
	public static uint copperCoin = 0;		//Стартовое количество медных монет

	/*-------------------------------------------------------------------*/

	void Update(){
		CollectCoin();
	}
			/*Метод подсчета монет*/
	void CollectCoin (){
		if (TapScreen.spawnEnemy && TapScreen.stopCollecting == false){
			copperCoin += stndCooper;
		}
	}
}