﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Timer : MonoBehaviour {
	public Text TimerText;

	private int timersecond;
	private float secondGameTime = 0;
	private float secondGameTimereset = 0;
	private float mineGameTime = 0;
	private float mineGameTimereset = 0;

	void Update () {
		SrcTimer ();
		TimerText.text = mineGameTime + ":" + timersecond;
	}

	void SrcTimer(){
		secondGameTime += Time.deltaTime;
		if (secondGameTime >= 1){
			timersecond += 1;
			secondGameTime = secondGameTimereset;
		}
		if (timersecond >= 60){
			mineGameTime += 1;
			timersecond = 0;
		}
		if (timersecond >= 60){
			mineGameTime = mineGameTimereset;
		}
	}
}