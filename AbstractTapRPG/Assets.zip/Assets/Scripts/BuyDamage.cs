﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class BuyDamage : MonoBehaviour {
	public uint dmg = 1;
	public uint cost = 1;
	public Text _text;

	void Update(){
		HideText ();
		AddDamage ();
	}
		
	void HideText(){
		if (Buttons.shopOn){
			_text.text = "+" + dmg + "dmg p/h\n" + "Cost: " + cost;
		} else if (Buttons.shopOn == false){
			_text.text = "";
		}
	}

	void AddDamage(){
		if (ShopButtons.buyDmg) {
			TapScreen.heroDamage += 1;
			ShopButtons.buyDmg = false;
		}
	}
}