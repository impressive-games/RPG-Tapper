﻿using UnityEngine;
using System.Collections;

public class Buttons : MonoBehaviour {
	public string action;
	public static bool shopOn;
	public static bool mouseOver;

	void OnMouseUpAsButton(){
		switch (action){
		case "ShopOn":
			Debug.Log ("ShopOn");
			shopOn = true;
			break;
		case "ShopOff":
			Debug.Log ("ShopOff");
			shopOn = false;
			break;
		case "Setting":
			Debug.Log ("Setting");
			break;
		case "Rating":
			Debug.Log ("Rating");
			break;
		}
	}
										/*ПРИ ПЕРЕНОСЕ СКРИПТА В ОСНОВНУЮ ИГРУ ПЕРЕИМЕНОВАТЬ В MenuButtons.cs*/
}