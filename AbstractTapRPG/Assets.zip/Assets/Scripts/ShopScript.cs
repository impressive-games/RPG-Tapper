﻿using UnityEngine;
using System.Collections;

public class ShopScript : MonoBehaviour {
	public GameObject ShopWallUp;		//Верхняя стена
	public GameObject ShopWallLeft;		//Левая стена
	public GameObject ShopWallRight;	//Правая стена
	public GameObject ShopWallDown;		//Пол(Нижняя стена)
	public GameObject ShopOn;			//Иконка "Открыть магазин"
	public GameObject ShopOff;			//Иконка "Закрыть магазин"
	public float speed;

	private Vector2 targetWallUp = new Vector2 (0f, 10f);			//Начало конечных координат
	private Vector2 targetWallLeft = new Vector2(-39f, 1.5f);
	private Vector2 targetWallRight = new Vector2(39f, 1.5f);
	private Vector2 targetWallDown = new Vector2(0f, -21f);

	private Vector2 startWallUp = new Vector2(0f, 65f);				//Начало стартовых координат
	private Vector2 startWallLeft = new Vector2(-78f, 1.5f);
	private Vector2 startWallRight = new Vector2(78f, 1.5f);
	private Vector2 startWallDown = new Vector2(0f, -42f);

/*-------------------------------------------------------------------------------------------------*/

				//При запуске приложения ставим стены в стартовые координаты и выключаем иконку "Закрыть магазин"
	void Awake(){
		ShopWallUp.transform.localPosition = startWallUp;
		ShopWallLeft.transform.localPosition = startWallLeft;
		ShopWallRight.transform.localPosition = startWallRight;
		ShopWallDown.transform.localPosition = startWallDown;
		ShopOff.SetActive (false);
	}

	void Update(){
		if (Buttons.shopOn == true) {		//Если мы нажимаем на кнопку "Shop"	в свитче Buttons, то стены двигаются в сторону таргета
			ShopWallUp.transform.localPosition = Vector2.MoveTowards(ShopWallUp.transform.localPosition, targetWallUp, speed);
			ShopWallLeft.transform.localPosition = Vector2.MoveTowards(ShopWallLeft.transform.localPosition, targetWallLeft, speed);
			ShopWallRight.transform.localPosition = Vector2.MoveTowards(ShopWallRight.transform.localPosition, targetWallRight, speed);
			ShopWallDown.transform.localPosition = Vector2.MoveTowards(ShopWallDown.transform.localPosition, targetWallDown, speed);
		} 
		if(Buttons.shopOn == false){		//Елси мы закрываем магазин, то стены возвращаются на стартовую позицию
			ShopWallUp.transform.localPosition = Vector2.MoveTowards(ShopWallUp.transform.localPosition, startWallUp, speed);	
			ShopWallLeft.transform.localPosition = Vector2.MoveTowards(ShopWallLeft.transform.localPosition, startWallLeft, speed);
			ShopWallRight.transform.localPosition = Vector2.MoveTowards(ShopWallRight.transform.localPosition, startWallRight, speed);
			ShopWallDown.transform.localPosition = Vector2.MoveTowards(ShopWallDown.transform.localPosition, startWallDown, speed);
		}
		ShopWalls ();
	}
			/*Метод активации движения стен*/
	void ShopWalls(){
		if (Buttons.shopOn == true) {
			ShopOn.SetActive (false);
			ShopOff.SetActive (true);
			TapScreen.stopCollecting = true;
//			Debug.Log ("Shop is opened");
		}else{
			ShopOff.SetActive (false);
			ShopOn.SetActive (true);
			TapScreen.stopCollecting = false;
//			Debug.Log ("Shop is closed");
		}
	}
}