﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class TapScreen : MonoBehaviour {

	public GameObject Hero;				//Указываем на героя
	public GameObject Enemy;			//Указываем на врага
	public Text countText;				//Показывает количество убитых врагов. Позже - количество полученного золота 
	public Text enemyHealthText;		//Временное обозначение жизни врага

	public Vector3 moveTarget;			//Вектор перемещения персонажа
	public Vector3 EnemyScale;			//На сколько увеличивается враг

	private uint enemyHealth = 10;					//Стартовое здоровье врагов
	public static bool spawnEnemy = false;			//Переменная появления врагов
	public static bool stopCollecting = false;		//Отвечает за остановку сбора монет
	public static uint heroDamage = 1;

/*-------------------------------------------------------------------------------------*/

	void Update () {
		countText.text = "Монет всего: " + CollectCoins.copperCoin;
		enemyHealthText.text = enemyHealth + "/10";

		Tap ();
		SpawnEnemy ();
	}
			/*Метод, когда игрок жмет по экрану*/
	void Tap (){
		if (Input.GetMouseButtonDown (0) && stopCollecting == false) { 
			Hero.transform.position = Hero.transform.position + moveTarget;			//Действие персонажа после нажатия на экран
			Enemy.transform.localScale = Enemy.transform.localScale + EnemyScale;
			if (stopCollecting == false) {
				enemyHealth -= heroDamage;
			}
		} 
		if (Input.GetMouseButtonUp (0) && stopCollecting == false){
			Hero.transform.position = Hero.transform.position - moveTarget;
			Enemy.transform.localScale = Enemy.transform.localScale - EnemyScale;
		}
	}
			/*Метод появления врага*/
	void SpawnEnemy(){
		if (enemyHealth <= 0) {
			spawnEnemy = true;
			enemyHealth = 10;
		} else {
			spawnEnemy = false;
		}
		if (Buttons.shopOn == true) {
			Enemy.SetActive (false);
			enemyHealthText.text = "";
		} else {
			Enemy.SetActive (true);
			enemyHealthText.text = enemyHealth + "/10";
		}
	}
}