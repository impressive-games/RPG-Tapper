﻿using UnityEngine;
using System.Collections;

public class ShopButtons : MonoBehaviour {
	public string _action;

	public static bool buyDmg = false;
	void OnMouseUpAsButton(){
		switch (_action){
		case "BuyDmg":
			buyDmg = true;
			Debug.Log ("Dmg +1");
			break;
		}
	}
}
